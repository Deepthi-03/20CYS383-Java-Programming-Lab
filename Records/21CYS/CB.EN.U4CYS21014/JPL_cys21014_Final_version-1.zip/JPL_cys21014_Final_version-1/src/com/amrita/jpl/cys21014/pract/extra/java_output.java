package com.amrita.jpl.cys21014.pract.extra;
/**
 * @author Deepthi Jayanth
 */
public class java_output{
    public static void main(String[] args){
        System.out.println("Hello World!");
        System.out.print("Let us"); System.out.print(" print numbers:");
        System.out.println(2);
        System.out.println(2+3+4);
        System.out.println(2*3);
        System.out.println(8/4);
        System.out.println(9%4);
    }
}

