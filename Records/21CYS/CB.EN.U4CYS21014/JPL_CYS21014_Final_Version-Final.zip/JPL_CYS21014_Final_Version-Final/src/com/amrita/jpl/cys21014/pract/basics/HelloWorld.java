package com.amrita.jpl.cys21014.pract.basics;

/**
 * @author Deepthi J
 * @version 1.0
 */

public class HelloWorld {
    /**
     * Main method that prints "Hello world!" to the console.
     *
     * @param args command line arguments
     */
    public static void main(String[] args) {
        System.out.println("Hello world!");
    }
}