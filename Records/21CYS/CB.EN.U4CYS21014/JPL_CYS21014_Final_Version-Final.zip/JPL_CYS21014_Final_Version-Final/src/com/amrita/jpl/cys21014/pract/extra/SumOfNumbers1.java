package com.amrita.jpl.cys21014.pract.extra;
/**
 * @author Deepthi Jayanth
 */
public class SumOfNumbers1
{
    public static void main(String[] args)
    {
        int n1 = 225, n2 = 115, sum;
        sum = n1 + n2;
        System.out.println("The sum of numbers is: "+sum);
    }
}