package com.amrita.jpl.cys21014.pract.extra;
/**
 * @author Deepthi Jayanth
 */
public class DifferenceOfNumbers1 {
    public static void main(String[] args){
        int n=1008, m=122, diff;
        diff = n - m;
        System.out.println("Difference of the two numbers = "+diff);
    }
}
