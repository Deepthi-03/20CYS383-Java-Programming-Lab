package com.amrita.jpl.cys21014.ex;

/**
 * @author Deepthi J
 * @version 1.0
 *
 */

public class pattern {
    public static void main(String[] args) {
        int i = 0;
        while (i < 3) {
            System.out.println("* * * * * * ==================================\n" +
                    "* * * * *  ===================================\n" +
                    "* * * * * * ==================================");
            i++;
        }
        i=0;
        while(i<6){
            System.out.println("==============================================");
            i++;
        }

    }
}