package com.amrita.filetransfer.cys21014;

import java.io.*;
import java.net.Socket;

/**
 * @author Deepthi J
 */

abstract class FileTransferListener {
    abstract void saveFile(String filename);

    abstract void sendFile(String filename);

    public abstract void onFileSent(String filename);

    public abstract void onFileSaved(String filename);
}
interface File_Client_Transfer_Listener {
    void onFileSent(String filename);
    void onFileSaved(String filename);

    void saveFile(byte[] fileData, String filename);

    void sendFile(String filename);
}
abstract class FileTransferClient implements File_Client_Transfer_Listener {
    private FileTransferListener listener;

    @Override
    public void saveFile(byte[] fileData, String filename) {
    }

    @Override
    public void sendFile(String filename) {
        try {
            Socket socket = new Socket("localhost", 8080);
            OutputStream outputStream = socket.getOutputStream();
            File file = new File(filename);
            FileInputStream fileInputStream = new FileInputStream(file);
            byte[] buffer = new byte[4096];
            int bytesRead;
            while ((bytesRead = fileInputStream.read(buffer)) != -1) {
                outputStream.write(buffer, 0, bytesRead);
            }
            fileInputStream.close();
            outputStream.close();
            socket.close();

            // Notify listener
            if (listener != null) {
                listener.sendFile(filename);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void setListener(FileTransferListener listener) {
        this.listener = listener;
    }
}

public class Client {

    public static void main(String[] args) {
        String filename = "D:\\java_project\\FileTransfer\\src\\com\\amrita\\filetransfer\\cys21014\\input.txt";
        String serverFilename = "D:\\java_project\\FileTransfer\\src\\com\\amrita\\filetransfer\\cys21014\\output.txt";

        try {
            Socket socket = new Socket("localhost", 8080);

            DataOutputStream dataOutputStream = new DataOutputStream(socket.getOutputStream());
            dataOutputStream.writeUTF(filename);

            FileInputStream fileInputStream = new FileInputStream(serverFilename);
            OutputStream outputStream = socket.getOutputStream();

            byte[] buffer = new byte[4096];
            int bytesRead;
            while ((bytesRead = fileInputStream.read(buffer)) != -1) {
                outputStream.write(buffer, 0, bytesRead);
            }

            outputStream.close();
            fileInputStream.close();
            socket.close();

            System.out.println("File that has been sent successfully: " + filename);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}